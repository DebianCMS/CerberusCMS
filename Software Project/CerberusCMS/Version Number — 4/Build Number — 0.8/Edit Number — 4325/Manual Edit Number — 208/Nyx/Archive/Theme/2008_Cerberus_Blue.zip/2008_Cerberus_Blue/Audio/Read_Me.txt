+ ======================================================= +
#THIS DIRECTORY CAN CONTAIN UP TO 5 MUSIC FILES FOR USE WITH THE MEMBER cPanel MODULE.
#THE MEMBER cPanel MODULE WILL PLAY THE ACCORDING RANKING MUSIC FILE.
#Rank_1.ext [ E.G.: .mp3, .wav, etc. ] // SET FORMAT THROUGH ADMIN SETTINGS.
#Rank_2.ext [ E.G.: .mp3, .wav, etc. ] // SET FORMAT THROUGH ADMIN SETTINGS.
#Rank_3.ext [ E.G.: .mp3, .wav, etc. ] // SET FORMAT THROUGH ADMIN SETTINGS.
#Rank_4.ext [ E.G.: .mp3, .wav, etc. ] // SET FORMAT THROUGH ADMIN SETTINGS.
#Rank_5.ext [ E.G.: .mp3, .wav, etc. ] // SET FORMAT THROUGH ADMIN SETTINGS.
+ ======================================================= +